import pickle

def save_data(file, data):
    with open(file, 'wb+') as save_file:
        try:
            pickle.dump(data, save_file, protocol = pickle.HIGHEST_PROTOCOL)
        except:
            print('Could Not Save')

def load_data(file):
    with open(file, 'rb') as load_file:
        return pickle.load(load_file)
